import React from 'react'
import HomePage from './HomePage'

const LandingPage: React.FC = () => {
  return <HomePage />
}

export default LandingPage

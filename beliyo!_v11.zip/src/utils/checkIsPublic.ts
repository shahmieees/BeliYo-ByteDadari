export function checkIsPublic(obj: any): boolean {
  if (!obj) {
    console.warn('Attempted to access isPublic on a null object')
    return false // Default to false if obj is null
  }
  return obj.isPublic || false
}
